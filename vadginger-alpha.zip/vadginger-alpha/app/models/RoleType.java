package models;

public enum RoleType {
  MEMBER, ORG_ADMIN, ADMIN, SUPER_ADMIN;
}

