

INSERT INTO Materials (id,Naam, IsActive) VALUES (1,'Zelf ontwikkeld materiaal',1);
INSERT INTO Materials (id,Naam, IsActive) VALUES (2,'Materiaal van VAD/De DrugLijn',1);
INSERT INTO Materials (id,Naam, IsActive) VALUES (3,'Ander materiaal op Vlaams niveau',1);
INSERT INTO Materials (id,Naam, IsActive) VALUES (4,'Ander materiaal op lokaal/regionaal niveau',1);
INSERT INTO Materials (id,Naam, IsActive) VALUES (5,'Ander materiaal op internationaal niveau',1);
INSERT INTO Materials (id,Naam, IsActive) VALUES (6,'Ander materiaal op federaal niveau',1);
INSERT INTO Materials (id,Naam, IsActive) VALUES (7,'Geen materiaal',1);



