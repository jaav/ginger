UPDATE Activity SET TotalParticipants = 2 WHERE TotalParticipants = 11;
UPDATE Activity SET TotalParticipants = 6 WHERE TotalParticipants = 2;
UPDATE Activity SET TotalParticipants = 17 WHERE TotalParticipants = 3;
UPDATE Activity SET TotalParticipants = 37 WHERE TotalParticipants = 4;
UPDATE Activity SET TotalParticipants = 75 WHERE TotalParticipants = 5;
UPDATE Activity SET TotalParticipants = 150 WHERE TotalParticipants = 6;
